"""Rule-based URL classification used by the backend.

The first MVP only needs deterministic categories so that the browser extension
and the dashboard behave predictably during demos.
"""

from __future__ import annotations

from urllib.parse import urlparse

STUDY_DOMAINS = {
    "youdao.com",
    "shanbay.com",
    "quizlet.com",
    "coursera.org",
    "icourse163.org",
}

DISTRACT_DOMAINS = {
    "douyin.com",
    "bilibili.com",
    "youtube.com",
    "weibo.com",
    "xiaohongshu.com",
    "kuaishou.com",
}


def normalize_hostname(url_or_hostname: str) -> str:
    """Normalize a raw URL or hostname into a comparable hostname string."""
    candidate = (url_or_hostname or "").strip()
    if not candidate:
        return ""

    parsed = urlparse(candidate if "://" in candidate else f"https://{candidate}")
    hostname = parsed.hostname or ""
    return hostname.removeprefix("www.")


def _matches_domain(hostname: str, allowed_domains: set[str]) -> bool:
    """Support exact domain matches and subdomain matches."""
    return any(
        hostname == domain or hostname.endswith(f".{domain}")
        for domain in allowed_domains
    )


def classify_url(url: str) -> str:
    """Classify a URL as study, distract, or neutral."""
    hostname = normalize_hostname(url)
    if not hostname:
        return "neutral"

    if _matches_domain(hostname, STUDY_DOMAINS):
        return "study"

    if _matches_domain(hostname, DISTRACT_DOMAINS):
        return "distract"

    return "neutral"
