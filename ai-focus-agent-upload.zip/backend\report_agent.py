"""Report generation helpers for AI Focus Agent.

This file intentionally keeps the report generation logic separate so that a
future LLM-backed report generator can replace the rules without changing the API layer.
"""

from __future__ import annotations

from collections import Counter
from typing import Any


def _build_suggestions(top_source: str, distract_count: int) -> list[str]:
    """Generate lightweight coaching suggestions based on the main distraction source."""
    if distract_count == 0:
        return [
            "继续保持当前的任务节奏，复用今天的学习时间安排。",
            "在下一个学习时段开始前，提前准备好学习资料和目标清单。",
        ]

    if any(keyword in top_source for keyword in ["douyin", "bilibili", "youtube", "kuaishou"]):
        return [
            "进入学习时段前，先关闭短视频站点或退出登录，减少手动点开的冲动。",
            "把娱乐视频安排到学习结束后的固定休息时间，而不是穿插在任务中。",
        ]

    if any(keyword in top_source for keyword in ["weibo", "xiaohongshu"]):
        return [
            "学习阶段可开启浏览器分组，只保留学习标签页，降低社交信息流干扰。",
            "把社交查看集中到学习结束后的 10 分钟总结时间，避免中途切换。",
        ]

    return [
        "开始学习前先关闭与任务无关的标签页，减少中断入口。",
        "如果需要中途查资料，优先用单独窗口打开，避免顺手切到娱乐站点。",
    ]


def build_focus_report(
    task: dict[str, Any],
    events: list[dict[str, Any]],
    summary: dict[str, Any],
) -> dict[str, Any]:
    """Build a human-readable review report and a structured summary payload."""
    task_name = task.get("taskName") or "尚未设置学习任务"
    goal = task.get("goal") or "未填写目标说明"
    planned_minutes = summary.get("plannedDurationMinutes", 0)
    focus_minutes = summary.get("focusDurationMinutes", 0)
    distract_count = summary.get("distractCount", 0)
    top_source = summary.get("mainDistractionSource", "无")
    source_counter = Counter(event.get("domain", "unknown") for event in events)
    source_summary = "、".join(
        f"{domain}（{count}次）" for domain, count in source_counter.most_common(3)
    ) or "无分心记录"

    if planned_minutes > 0:
        completion_ratio = round((focus_minutes / planned_minutes) * 100)
    else:
        completion_ratio = 0

    if distract_count == 0:
        conclusion = "本次学习时段整体保持稳定，未出现明显的娱乐网站分心行为。"
    elif distract_count <= 2:
        conclusion = "本次学习总体可控，但仍存在少量分心切换，建议继续压缩娱乐站点打开次数。"
    elif distract_count <= 5:
        conclusion = "本次学习出现了较明显的注意力波动，建议在下一个时段提前做好站点干扰隔离。"
    else:
        conclusion = "本次学习分心行为较多，已经显著影响任务连续性，需要优化学习前的环境准备。"

    suggestions = _build_suggestions(top_source, distract_count)
    report = "\n\n".join(
        [
            f"今日学习任务：{task_name}",
            f"目标说明：{goal}",
            f"计划学习时长：{planned_minutes} 分钟；估算有效专注时长：{focus_minutes} 分钟；完成度约为 {completion_ratio}%。",
            f"分心次数：{distract_count} 次；主要分心来源：{top_source}；分心站点分布：{source_summary}。",
            f"复盘结论：{conclusion}",
            "建议："
            + "".join(f"\n- {suggestion}" for suggestion in suggestions),
        ]
    )

    return {
        "report": report,
        "summary": summary,
        "suggestions": suggestions,
    }
