"""FastAPI backend for AI Focus Agent.

This MVP stores data in local JSON files and exposes a small API surface for
URL classification, focus event ingestion, dashboard queries, and report generation.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any
import json

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from focus_rules import classify_url
from report_agent import build_focus_report

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
EVENTS_FILE = DATA_DIR / "focus_events.json"
TASK_FILE = DATA_DIR / "current_task.json"

app = FastAPI(title="AI Focus Agent API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class UrlPayload(BaseModel):
    """Request model for the classify-url endpoint."""

    url: str


class TaskPayload(BaseModel):
    """Request model for syncing the current task from the extension."""

    taskName: str = Field(..., min_length=1)
    startTime: str
    endTime: str
    goal: str = Field(..., min_length=1)
    savedAt: str | None = None


class FocusEventPayload(BaseModel):
    """Request model for distraction events sent by the extension."""

    timestamp: str
    eventDate: str | None = None
    displayTime: str | None = None
    url: str
    domain: str
    category: str = "distract"
    taskName: str
    goal: str | None = None
    startTime: str | None = None
    endTime: str | None = None
    alertLevel: str = "high"


class GenerateReportPayload(BaseModel):
    """Optional request body for future report generation flags."""

    includeAllEvents: bool = False


def ensure_storage() -> None:
    """Create the local storage files the first time the backend starts."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if not EVENTS_FILE.exists():
        write_json(EVENTS_FILE, [])

    if not TASK_FILE.exists():
        write_json(TASK_FILE, {})


def read_json(path: Path, default: Any) -> Any:
    """Read a JSON file safely and fall back to a default structure when needed."""
    if not path.exists():
        return default

    try:
        with path.open("r", encoding="utf-8") as file:
            return json.load(file)
    except (OSError, json.JSONDecodeError):
        return default


def write_json(path: Path, payload: Any) -> None:
    """Write JSON using UTF-8 so the local demo data remains easy to inspect."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, indent=2)


def parse_time_to_minutes(time_string: str | None) -> int:
    """Convert an HH:MM time string to minutes for simple duration estimates."""
    if not time_string or ":" not in time_string:
        return 0

    try:
        hours, minutes = [int(part) for part in time_string.split(":")]
    except ValueError:
        return 0

    return hours * 60 + minutes


def calculate_planned_duration_minutes(task: dict[str, Any]) -> int:
    """Estimate the study duration from the saved task window."""
    start_minutes = parse_time_to_minutes(task.get("startTime"))
    end_minutes = parse_time_to_minutes(task.get("endTime"))
    if end_minutes <= start_minutes:
        return 0
    return end_minutes - start_minutes


def today_key() -> str:
    """Return the backend-local date string used to group records in the dashboard."""
    return datetime.now().strftime("%Y-%m-%d")


def get_current_task() -> dict[str, Any]:
    """Load the most recently synced study task."""
    return read_json(TASK_FILE, {})


def get_all_events() -> list[dict[str, Any]]:
    """Load all stored distraction events."""
    events = read_json(EVENTS_FILE, [])
    return events if isinstance(events, list) else []


def get_today_events(include_all_events: bool = False) -> list[dict[str, Any]]:
    """Return either today's events or the full history, depending on the request."""
    events = get_all_events()
    if include_all_events:
        return events

    current_day = today_key()
    return [event for event in events if event.get("eventDate") == current_day]


def build_dashboard_summary() -> dict[str, Any]:
    """Aggregate card-level data for the React dashboard."""
    task = get_current_task()
    today_events = get_today_events()
    planned_duration_minutes = calculate_planned_duration_minutes(task)
    distract_count = len(today_events)
    focus_duration_minutes = max(planned_duration_minutes - distract_count * 5, 0)
    domain_counter = Counter(event.get("domain", "unknown") for event in today_events)
    main_source = domain_counter.most_common(1)[0][0] if domain_counter else "\u65e0"

    return {
        "task": task,
        "plannedDurationMinutes": planned_duration_minutes,
        "focusDurationMinutes": focus_duration_minutes,
        "distractCount": distract_count,
        "mainDistractionSource": main_source,
        "eventCount": distract_count,
        "lastUpdated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


@app.on_event("startup")
def on_startup() -> None:
    """Prepare data files before serving requests."""
    ensure_storage()


@app.get("/health")
def health_check() -> dict[str, str]:
    """Basic health endpoint for quick startup verification."""
    return {"status": "ok"}


@app.post("/api/classify-url")
def classify_url_endpoint(payload: UrlPayload) -> dict[str, str]:
    """Classify a URL using the same study/distract/neutral rules as the extension."""
    return {"category": classify_url(payload.url)}


@app.post("/api/current-task")
def save_current_task(payload: TaskPayload) -> dict[str, Any]:
    """Sync the latest study task from the extension popup to local JSON storage."""
    task = payload.model_dump()
    task["savedAt"] = task.get("savedAt") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    write_json(TASK_FILE, task)
    return {"success": True, "task": task}


@app.get("/api/current-task")
def read_current_task() -> dict[str, Any]:
    """Expose the current task to any client that wants direct task details."""
    return {"task": get_current_task()}


@app.post("/api/focus-event")
def save_focus_event(payload: FocusEventPayload) -> dict[str, Any]:
    """Persist one distraction event to the local JSON file."""
    events = get_all_events()
    event = payload.model_dump()
    event["eventDate"] = event.get("eventDate") or today_key()
    event["displayTime"] = event.get("displayTime") or datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    events.append(event)
    write_json(EVENTS_FILE, events)

    if payload.taskName:
        latest_task = {
            "taskName": payload.taskName,
            "goal": payload.goal or "",
            "startTime": payload.startTime or "",
            "endTime": payload.endTime or "",
            "savedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        write_json(TASK_FILE, latest_task)

    return {"success": True, "event": event}


@app.get("/api/focus-events")
def list_focus_events() -> dict[str, list[dict[str, Any]]]:
    """Return today's distraction records for the dashboard table."""
    events = sorted(
        get_today_events(),
        key=lambda item: item.get("timestamp", ""),
        reverse=True,
    )
    return {"events": events}


@app.get("/api/dashboard-summary")
def dashboard_summary() -> dict[str, Any]:
    """Return the aggregated data shown in the dashboard cards."""
    return {"summary": build_dashboard_summary()}


@app.post("/api/generate-report")
def generate_report(payload: GenerateReportPayload | None = None) -> dict[str, Any]:
    """Generate a rule-based daily report for the dashboard."""
    include_all_events = payload.includeAllEvents if payload else False
    events = get_today_events(include_all_events=include_all_events)
    summary = build_dashboard_summary()
    report_payload = build_focus_report(get_current_task(), events, summary)
    return report_payload
