// Popup logic for saving the current study task.
// It stores the task locally, syncs it to the backend, and refreshes the summary panel.

const BACKEND_BASE_URL = "http://127.0.0.1:8000";

function storageGet(defaults) {
  return new Promise((resolve) => {
    chrome.storage.local.get(defaults, (items) => resolve(items));
  });
}

function storageSet(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, resolve);
  });
}

function currentTimestamp() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function showStatus(message, variant = "") {
  const statusMessage = document.getElementById("statusMessage");
  statusMessage.textContent = message;
  statusMessage.className = `status-message ${variant}`.trim();
}

function renderTaskSummary(task, focusEvents) {
  const taskSummary = document.getElementById("taskSummary");
  const eventSummary = document.getElementById("eventSummary");

  if (task?.taskName) {
    taskSummary.textContent = `当前任务：${task.taskName}（${task.startTime} - ${task.endTime}）`;
  } else {
    taskSummary.textContent = "尚未设置学习任务。";
  }

  eventSummary.textContent = `今日本地记录的分心次数：${focusEvents.length}`;
}

async function syncTaskToBackend(task) {
  await fetch(`${BACKEND_BASE_URL}/api/current-task`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(task)
  });
}

async function loadExistingState() {
  const storage = await storageGet({ currentTask: null, focusEvents: [] });
  const currentTask = storage.currentTask;

  if (currentTask) {
    document.getElementById("taskName").value = currentTask.taskName || "";
    document.getElementById("startTime").value = currentTask.startTime || "";
    document.getElementById("endTime").value = currentTask.endTime || "";
    document.getElementById("goal").value = currentTask.goal || "";
  }

  renderTaskSummary(currentTask, storage.focusEvents || []);
}

async function handleSubmit(event) {
  event.preventDefault();

  const taskName = document.getElementById("taskName").value.trim();
  const startTime = document.getElementById("startTime").value;
  const endTime = document.getElementById("endTime").value;
  const goal = document.getElementById("goal").value.trim();

  if (!taskName || !startTime || !endTime || !goal) {
    showStatus("请完整填写学习任务信息。", "error");
    return;
  }

  if (endTime <= startTime) {
    showStatus("第一版原型暂不支持跨天学习时段，请设置同一天内的开始和结束时间。", "error");
    return;
  }

  const task = {
    taskName,
    startTime,
    endTime,
    goal,
    savedAt: currentTimestamp()
  };

  await storageSet({ currentTask: task });
  chrome.runtime.sendMessage({ type: "task-updated" });

  try {
    await syncTaskToBackend(task);
    showStatus("学习任务已保存，并已同步到后端。", "success");
  } catch (error) {
    console.warn("Failed to sync task to backend.", error);
    showStatus("学习任务已保存到本地，但后端未启动或同步失败。", "warning");
  }

  const storage = await storageGet({ focusEvents: [] });
  renderTaskSummary(task, storage.focusEvents || []);
}

document.addEventListener("DOMContentLoaded", async () => {
  await loadExistingState();
  document.getElementById("taskForm").addEventListener("submit", handleSubmit);
});
