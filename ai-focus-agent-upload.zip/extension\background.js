// Background service worker for the Chrome extension.
// It watches active tabs, classifies URLs, stores distraction events,
// syncs them to the backend, and shows study reminders during the task window.

const BACKEND_BASE_URL = "http://127.0.0.1:8000";
const STUDY_DOMAINS = [
  "youdao.com",
  "shanbay.com",
  "quizlet.com",
  "coursera.org",
  "icourse163.org"
];
const DISTRACT_DOMAINS = [
  "douyin.com",
  "bilibili.com",
  "youtube.com",
  "weibo.com",
  "xiaohongshu.com",
  "kuaishou.com"
];
const DUPLICATE_EVENT_WINDOW_MS = 60 * 1000;
const recentEventCache = new Map();

function storageGet(defaults) {
  return new Promise((resolve) => {
    chrome.storage.local.get(defaults, (items) => resolve(items));
  });
}

function storageSet(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, resolve);
  });
}

function createNotification(notificationId, options) {
  return new Promise((resolve) => {
    chrome.notifications.create(notificationId, options, resolve);
  });
}

function queryActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0]));
  });
}

function getTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError) {
        resolve(null);
        return;
      }
      resolve(tab);
    });
  });
}

function normalizeHostname(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.hostname.replace(/^www\./, "");
  } catch (error) {
    return "";
  }
}

function matchesDomain(hostname, candidates) {
  return candidates.some(
    (candidate) => hostname === candidate || hostname.endsWith(`.${candidate}`)
  );
}

function classifyUrl(rawUrl) {
  const hostname = normalizeHostname(rawUrl);
  if (!hostname) {
    return "neutral";
  }

  if (matchesDomain(hostname, STUDY_DOMAINS)) {
    return "study";
  }

  if (matchesDomain(hostname, DISTRACT_DOMAINS)) {
    return "distract";
  }

  return "neutral";
}

function formatDatePart(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDateTime(date) {
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");
  return `${formatDatePart(date)} ${hours}:${minutes}:${seconds}`;
}

function timeStringToMinutes(timeString) {
  if (!timeString || !timeString.includes(":")) {
    return null;
  }

  const [hours, minutes] = timeString.split(":").map(Number);
  if (Number.isNaN(hours) || Number.isNaN(minutes)) {
    return null;
  }

  return hours * 60 + minutes;
}

function isWithinStudyWindow(task) {
  if (!task?.startTime || !task?.endTime) {
    return false;
  }

  const startMinutes = timeStringToMinutes(task.startTime);
  const endMinutes = timeStringToMinutes(task.endTime);
  if (startMinutes === null || endMinutes === null || endMinutes <= startMinutes) {
    return false;
  }

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
}

function shouldSkipDuplicate(tabId, url) {
  const fingerprint = `${tabId}:${url}`;
  const now = Date.now();
  const lastRecordedAt = recentEventCache.get(fingerprint);

  if (lastRecordedAt && now - lastRecordedAt < DUPLICATE_EVENT_WINDOW_MS) {
    return true;
  }

  recentEventCache.set(fingerprint, now);
  return false;
}

async function saveFocusEventLocally(event) {
  const storage = await storageGet({ focusEvents: [] });
  const nextEvents = [event, ...(storage.focusEvents || [])].slice(0, 300);
  await storageSet({ focusEvents: nextEvents });
}

async function sendFocusEventToBackend(event) {
  try {
    await fetch(`${BACKEND_BASE_URL}/api/focus-event`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(event)
    });
  } catch (error) {
    console.warn("Failed to sync focus event to backend.", error);
  }
}

async function showDistractNotification(taskName) {
  const notificationId = `focus-alert-${Date.now()}`;
  await createNotification(notificationId, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icon128.png"),
    title: "AI Focus Agent 学习提醒",
    message: `你当前任务是${taskName}，已经偏离学习状态，请先回到任务。`,
    priority: 2
  });
}

async function handlePotentialDistraction(tab) {
  if (!tab?.id || !tab.url || !tab.url.startsWith("http")) {
    return;
  }

  const storage = await storageGet({ currentTask: null });
  const currentTask = storage.currentTask;
  if (!currentTask?.taskName || !isWithinStudyWindow(currentTask)) {
    return;
  }

  const category = classifyUrl(tab.url);
  if (category !== "distract" || shouldSkipDuplicate(tab.id, tab.url)) {
    return;
  }

  const now = new Date();
  const event = {
    timestamp: now.toISOString(),
    eventDate: formatDatePart(now),
    displayTime: formatDateTime(now),
    url: tab.url,
    domain: normalizeHostname(tab.url) || "unknown",
    category,
    taskName: currentTask.taskName,
    goal: currentTask.goal || "",
    startTime: currentTask.startTime,
    endTime: currentTask.endTime,
    alertLevel: "high"
  };

  await saveFocusEventLocally(event);
  await sendFocusEventToBackend(event);
  await showDistractNotification(currentTask.taskName);
}

async function reevaluateActiveTab() {
  const activeTab = await queryActiveTab();
  await handlePotentialDistraction(activeTab);
}

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await storageGet({ focusEvents: [], currentTask: null });
  await storageSet({
    focusEvents: existing.focusEvents || [],
    currentTask: existing.currentTask || null
  });
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const activeTab = await getTab(activeInfo.tabId);
  await handlePotentialDistraction(activeTab);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const hasRelevantChange = Boolean(changeInfo.url) || changeInfo.status === "complete";
  if (!hasRelevantChange || !tab?.active) {
    return;
  }

  const currentTab = tab.id ? tab : await getTab(tabId);
  await handlePotentialDistraction(currentTab);
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "task-updated") {
    reevaluateActiveTab();
  }
});
