// Main React dashboard for the AI Focus Agent MVP.
// It loads summary metrics, renders the focus event table, and requests the daily report on demand.

import { useEffect, useState } from "react";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

const TYPE_LABELS = {
  study: "学习类",
  distract: "娱乐类",
  neutral: "中性类"
};

function formatDuration(minutes) {
  if (!minutes) {
    return "0 分钟";
  }

  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;

  if (!hours) {
    return `${remainingMinutes} 分钟`;
  }

  if (!remainingMinutes) {
    return `${hours} 小时`;
  }

  return `${hours} 小时 ${remainingMinutes} 分钟`;
}

function getDisplayDomain(url, domain) {
  if (domain) {
    return domain;
  }

  try {
    return new URL(url).hostname;
  } catch (error) {
    return url || "未知网站";
  }
}

async function fetchJson(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, options);
  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }
  return response.json();
}

export default function App() {
  const [summary, setSummary] = useState({
    task: {},
    focusDurationMinutes: 0,
    distractCount: 0,
    mainDistractionSource: "无"
  });
  const [events, setEvents] = useState([]);
  const [report, setReport] = useState("");
  const [loading, setLoading] = useState(true);
  const [reportLoading, setReportLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDashboard() {
      try {
        setLoading(true);
        setError("");
        const [summaryResponse, eventsResponse] = await Promise.all([
          fetchJson("/api/dashboard-summary"),
          fetchJson("/api/focus-events")
        ]);
        setSummary(summaryResponse.summary);
        setEvents(eventsResponse.events || []);
      } catch (requestError) {
        setError("无法连接后端，请先启动 FastAPI 服务。");
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  async function handleGenerateReport() {
    try {
      setReportLoading(true);
      setError("");
      const response = await fetchJson("/api/generate-report", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({})
      });
      setReport(response.report || "今日暂无可生成的复盘内容。");
    } catch (requestError) {
      setError("复盘报告生成失败，请确认后端正在运行。");
    } finally {
      setReportLoading(false);
    }
  }

  const currentTaskName = summary.task?.taskName || "尚未同步任务";
  const currentGoal = summary.task?.goal || "请先在浏览器插件中设置学习任务。";

  return (
    <div className="page-shell">
      <header className="hero">
        <div>
          <p className="hero-eyebrow">Focus Prototype</p>
          <h1>AI Focus Agent 学习专注监督助手</h1>
          <p className="hero-subtitle">
            通过浏览器插件捕捉分心行为，并在本地生成可演示的学习专注复盘。
          </p>
        </div>
        <button className="report-button" onClick={handleGenerateReport} disabled={reportLoading}>
          {reportLoading ? "生成中..." : "生成今日复盘报告"}
        </button>
      </header>

      {error ? <div className="error-banner">{error}</div> : null}

      <section className="cards-grid">
        <article className="stat-card featured">
          <p className="card-label">今日学习任务</p>
          <h2>{currentTaskName}</h2>
          <p className="card-note">{currentGoal}</p>
        </article>

        <article className="stat-card">
          <p className="card-label">专注时长</p>
          <h2>{loading ? "--" : formatDuration(summary.focusDurationMinutes)}</h2>
          <p className="card-note">基于学习时段和分心事件的规则估算</p>
        </article>

        <article className="stat-card">
          <p className="card-label">分心次数</p>
          <h2>{loading ? "--" : summary.distractCount}</h2>
          <p className="card-note">仅统计学习时段内的娱乐网站访问</p>
        </article>

        <article className="stat-card">
          <p className="card-label">主要分心来源</p>
          <h2>{loading ? "--" : summary.mainDistractionSource}</h2>
          <p className="card-note">帮助定位最需要治理的注意力入口</p>
        </article>
      </section>

      <section className="panel">
        <div className="panel-header">
          <div>
            <h3>学习记录表格</h3>
            <p>记录浏览器插件上报的分心事件，便于复盘查看。</p>
          </div>
          <span className="panel-badge">今日 {events.length} 条</span>
        </div>

        <div className="table-wrap">
          <table className="records-table">
            <thead>
              <tr>
                <th>时间</th>
                <th>访问网站</th>
                <th>类型</th>
                <th>提醒级别</th>
              </tr>
            </thead>
            <tbody>
              {events.length === 0 ? (
                <tr>
                  <td colSpan="4" className="empty-cell">
                    暂无分心记录。先在插件中设置任务，再尝试打开娱乐网站进行联调。
                  </td>
                </tr>
              ) : (
                events.map((event, index) => (
                  <tr key={`${event.timestamp}-${index}`}>
                    <td>{event.displayTime || event.timestamp}</td>
                    <td>{getDisplayDomain(event.url, event.domain)}</td>
                    <td>{TYPE_LABELS[event.category] || event.category}</td>
                    <td>{event.alertLevel || "high"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="panel report-panel">
        <div className="panel-header">
          <div>
            <h3>今日复盘报告</h3>
            <p>第一版使用规则模板生成，后续可替换为大模型总结。</p>
          </div>
        </div>

        <div className="report-box">
          {report ? (
            report.split("\n").map((paragraph, index) => (
              <p key={`${paragraph}-${index}`}>{paragraph}</p>
            ))
          ) : (
            <p className="report-placeholder">点击上方按钮后，在这里展示今日学习复盘报告。</p>
          )}
        </div>
      </section>
    </div>
  );
}
