# AI Focus Agent

AI Focus Agent 是一个面向学习场景的专注监督助手原型，包含：

- Chrome 插件：设置学习任务、监听当前网页、识别分心访问并提醒。
- FastAPI 后端：规则分类 URL、保存分心事件、生成复盘报告。
- React 仪表盘：展示当日任务、专注统计、分心记录和复盘结果。

这个版本是可运行、可截图、可演示的 MVP，不依赖数据库，数据全部保存在本地 JSON 文件中。

## 项目结构

```text
ai-focus-agent/
├─ extension/
│  ├─ manifest.json
│  ├─ background.js
│  ├─ content.js
│  ├─ popup.html
│  ├─ popup.js
│  ├─ styles.css
│  └─ icon128.png
│
├─ backend/
│  ├─ main.py
│  ├─ focus_rules.py
│  ├─ report_agent.py
│  ├─ requirements.txt
│  └─ data/                  # 启动后自动生成
│
└─ web-dashboard/
   ├─ package.json
   ├─ index.html
   └─ src/
      ├─ App.jsx
      ├─ main.jsx
      └─ styles.css
```

## 功能概览

### 1. Chrome 插件

- 使用 Chrome Extension Manifest V3。
- 在 popup 中设置学习任务：
  - 学习任务名称
  - 开始时间
  - 结束时间
  - 目标说明
- 监听当前激活标签页变化和 URL 变化。
- 内置站点分类规则：
  - 学习类：`youdao.com`、`shanbay.com`、`quizlet.com`、`coursera.org`、`icourse163.org`
  - 娱乐类：`douyin.com`、`bilibili.com`、`youtube.com`、`weibo.com`、`xiaohongshu.com`、`kuaishou.com`
  - 其他：`neutral`
- 在学习时段访问娱乐网站时：
  - 记录一次分心事件
  - 触发 Chrome 通知提醒
  - 自动把事件上报给后端
- 学习任务和本地事件会保存到 `chrome.storage.local`。

### 2. FastAPI 后端

- `GET /health`
- `POST /api/classify-url`
- `POST /api/focus-event`
- `POST /api/generate-report`

为了让仪表盘直接展示状态，还补充了：

- `POST /api/current-task`
- `GET /api/current-task`
- `GET /api/dashboard-summary`
- `GET /api/focus-events`

后端会把数据保存到：

- `backend/data/current_task.json`
- `backend/data/focus_events.json`

### 3. React 仪表盘

- 页面标题：`AI Focus Agent 学习专注监督助手`
- 四张统计卡片：
  - 今日学习任务
  - 专注时长
  - 分心次数
  - 主要分心来源
- 一个学习记录表格：
  - 时间
  - 访问网站
  - 类型
  - 提醒级别
- 一个“生成今日复盘报告”按钮
- 点击按钮后调用后端生成规则版复盘报告

## 技术栈

- 插件：Chrome Extension Manifest V3
- 后端：FastAPI
- 前端：React + Vite
- 存储：本地 JSON 文件

## 本地运行

### 一、启动后端

进入后端目录：

```powershell
cd C:\Users\Lenovo\Desktop\Focus\ai-focus-agent\backend
```

创建并激活虚拟环境：

```powershell
python -m venv .venv
.venv\Scripts\activate
```

安装依赖：

```powershell
pip install -r requirements.txt
```

启动 FastAPI：

```powershell
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

健康检查：

```text
http://127.0.0.1:8000/health
```

正常返回：

```json
{"status":"ok"}
```

### 二、启动前端

进入前端目录：

```powershell
cd C:\Users\Lenovo\Desktop\Focus\ai-focus-agent\web-dashboard
```

安装依赖：

```powershell
npm.cmd install
```

启动开发服务器：

```powershell
npm.cmd run dev
```

打开：

```text
http://127.0.0.1:5173
```

说明：在 Windows PowerShell 下优先使用 `npm.cmd`，避免系统执行策略拦截 `npm.ps1`。

### 三、加载 Chrome 插件

1. 打开 `chrome://extensions`
2. 开启右上角“开发者模式”
3. 点击“加载已解压的扩展程序”
4. 选择目录：

```text
C:\Users\Lenovo\Desktop\Focus\ai-focus-agent\extension
```

加载成功后，浏览器工具栏会出现 AI Focus Agent 图标。

## 如何测试“学习时打开娱乐网站会提醒”

### 推荐测试顺序

1. 先启动 FastAPI 后端
2. 再启动 React 仪表盘
3. 最后加载 Chrome 插件

### 具体步骤

1. 点击浏览器工具栏里的 AI Focus Agent 插件图标。
2. 设置一个覆盖当前时间的学习任务，例如：
   - 学习任务名称：`背英语单词`
   - 开始时间：当前时间前 5 分钟
   - 结束时间：当前时间后 30 分钟
   - 目标说明：`完成 50 个单词记忆`
3. 点击“保存学习任务”。
4. 打开一个娱乐网站，例如：
   - `https://www.douyin.com`
   - `https://www.bilibili.com`
   - `https://www.youtube.com`
5. 如果当前时间位于学习时段，插件会：
   - 弹出提醒通知
   - 把分心事件保存到本地
   - 自动上报到后端
6. 打开仪表盘 `http://127.0.0.1:5173`，可以看到：
   - 分心次数增加
   - 主要分心来源更新
   - 学习记录表格出现一条新记录
7. 点击“生成今日复盘报告”，即可查看规则生成的复盘内容。

## API 示例

### `GET /health`

返回：

```json
{"status":"ok"}
```

### `POST /api/classify-url`

请求：

```json
{
  "url": "https://www.bilibili.com/video/BV1xx"
}
```

返回：

```json
{
  "category": "distract"
}
```

### `POST /api/focus-event`

请求：

```json
{
  "timestamp": "2026-05-05T11:20:00",
  "eventDate": "2026-05-05",
  "displayTime": "2026-05-05 11:20:00",
  "url": "https://www.bilibili.com/video/BV1xx",
  "domain": "bilibili.com",
  "category": "distract",
  "taskName": "背英语单词",
  "goal": "完成 50 个单词记忆",
  "startTime": "19:00",
  "endTime": "20:30",
  "alertLevel": "high"
}
```

### `POST /api/generate-report`

请求：

```json
{}
```

返回结构包含：

- `report`
- `summary`
- `suggestions`

## 当前版本限制

- 仅支持单用户本地演示
- 不支持跨天学习时段，例如 `23:00` 到次日 `01:00`
- 专注时长为规则估算值，不是精确行为轨迹分析
- 报告生成目前是规则模板，后续可以在 `report_agent.py` 中替换为真实 LLM

## 后续可扩展方向

- 增加用户登录和云端同步
- 接入真实大模型生成个性化复盘
- 支持更细粒度的网站分类和白名单/黑名单
- 增加页面内提醒、番茄钟和任务完成打卡
- 增加趋势图、周报和多日统计
